#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <sys/stat.h>

#define LISTEN_BACKLOG 50
#define BSIZE 4096 //block size - we are assuming 4KB blocks for simplicity, if the request is higher than 4KB, we will need to make multiple requests
#define PSIZE 512 //path size
#define PORT 5000
#define IP "127.0.0.1"
#define READ 0
#define WRITE 1

typedef struct msg{
	int op;
	char path[PSIZE];
	char buffer[BSIZE];
	off_t offset;
	size_t size;
	ssize_t res;
	struct stat st;
} MSG;


int connect_server();

void close_server(int client_fd);

ssize_t rpwrite(int client_fd, const char* path, const char *buffer, size_t size, off_t offset);

ssize_t rpread(int client_fd, const char* path, char *buffer, size_t size, off_t offset);

int rstat(int client_fd, const char* path, struct stat *stbuf);
