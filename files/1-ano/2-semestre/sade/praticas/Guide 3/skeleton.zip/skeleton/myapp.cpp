#include <iostream>
#include <sstream>
#include <string>
#include <ctime>
#include <random>
#include <chrono>
#include <thread>
#include <unistd.h>
#include <sys/types.h>

#include "leveldb/db.h"
#include "leveldb/options.h"

using namespace std;
using namespace leveldb;

namespace myapp {

    enum class Workload {
        writeseq,
        writerand,
        readseq,
        readrand
    };

    int FLAGS_key_prefix = 0;
    
    std::string kvs_path { "/mnt/fs/myapp-kvs" };
    
    const uint64_t key_size { 8 };
    const uint64_t value_size { 128 };

    #define DEBUG 

    class KeyGenerator { 
        private:
         char buffer_[1024];
        
        public:
            KeyGenerator() 
            {
                memset(buffer_, 'a', FLAGS_key_prefix);
            }
         
            KeyGenerator& operator=(KeyGenerator& other) = delete;
            KeyGenerator(KeyGenerator& other) = delete;
        
            void gen_key (int k) 
            {
                std::snprintf(buffer_ + FLAGS_key_prefix, sizeof(buffer_) - FLAGS_key_prefix, "%08d", k);
            }
       
            Slice slice() const 
            { 
                return Slice (buffer_, FLAGS_key_prefix + 8); 
            }
       
    };

    std::string generate_random_value (const size_t& value_size) {
        const std::string characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        std::random_device rd;
        std::mt19937 generator(rd());
        std::uniform_int_distribution<size_t> distribution(0, characters.size() - 1);
    
        std::string random_string;
        for (size_t i = 0; i < value_size; ++i) {
            random_string += characters[distribution(generator)];
        }
    
        return random_string;
    }

    void simple_put (DB* kvs, const int& key)
    {
        Status s;
        KeyGenerator key_;
        WriteOptions write_options;
        //write_options.sync = true;

        key_.gen_key(key);
        std::string value { generate_random_value (value_size) };

        // TODO
        // ... 

        if (!s.ok()) {
            std::cerr << "Add here an informative error message" << std::endl;
        } else {
            #ifdef DEBUG
                std::cout << "Add here an informative debugging message ..." << std::endl;
            #endif 
        }
    }

    void simple_get (DB* kvs, const int& key)
    {
        Status s;
        KeyGenerator key_;
        ReadOptions read_options;
        std::string value;

        key_.gen_key (key);
        
        // TODO
    }

    void simple_scan (DB* kvs, const int& start_key, const int& total)
    {
        Status s;
        KeyGenerator starting_key, ending_key;
        ReadOptions read_options;
        std::string value;
        int found = 0;
        
        starting_key.gen_key (start_key);
        ending_key.gen_key (start_key + total);
        
        // TODO 
    }

    void simple_delete (DB* kvs, const int& key)
    {
        Status s;
        KeyGenerator key_;
        WriteOptions write_options;

        key_.gen_key(key);

        // TODO
    }

    // Hint: implement this function using the simple_put operation
    void writeseq (DB* db, const int& total_ops)
    {
        // TODO
    }

    // Hint: implement this function using the simple_put operation
    void writerand (DB* db, const int& total_ops)
    {
        // TODO
    }

    // Hint: implement this function using the simple_get operation
    void readseq (DB* db, const int& total_ops)
    {
        // TODO
    }

    // Hint: implement this function using the simple_get operation
    void readrand (DB* db, const int& total_ops)
    {
        // TODO
    }

    std::chrono::duration<double> run_workload (DB* kvs, 
        const Workload& workload, 
        const int& total_ops, 
        const uint64_t& num_workers) 
    {
        std::thread workers [num_workers];

        auto workload_func = [] (DB* kvs, const Workload& workload, const int& total_ops) {
            switch (workload) {
                case Workload::writeseq:
                    std::cout << "[Thread " << std::this_thread::get_id() << ": writeseq workload ..." << std::endl;
                    writeseq (kvs, total_ops);
                    break;

                case Workload::writerand:
                    std::cout << "[Thread " << std::this_thread::get_id() << ": writerand workload ..." << std::endl;
                    writerand (kvs, total_ops);
                    break;

                case Workload::readseq:
                    std::cout << "[Thread " << std::this_thread::get_id() << ": readseq workload ..." << std::endl;
                    readseq (kvs, total_ops);
                    break;

                case Workload::readrand:
                    std::cout << "[Thread " << std::this_thread::get_id() << ": readrand workload ..." << std::endl;
                    readrand (kvs, total_ops);
                    break;
                default:
                    std::cerr << "[Thread " << std::this_thread::get_id() << ": undefined workload ... " << std::endl;
                    break;
            }
        }; 

    
        auto start = std::chrono::high_resolution_clock::now ();

        for (int i = 0; i < num_workers; i++) {
            workers[i] = std::thread (workload_func, std::ref(kvs), workload, total_ops);
        }

        for (int i = 0; i < num_workers; i++) {
            workers[i].join();
        }

        auto end = std::chrono::high_resolution_clock::now ();
        std::chrono::duration<double> elapsed_time_in_micros = end - start;

        return elapsed_time_in_micros;
    }
}


int main(int argc, char** argv)
{
    // Set up KVS options and open the KVS
    DB* kvs;

    Options options;
    options.create_if_missing = true;               // create kvs if missing
    options.write_buffer_size = 64 * 1024 * 1024;   // memtable size
    options.max_file_size = 64 * 1024 * 1024;       // SST file size (.ldb)
    options.compression = kNoCompression;           // disable compression

    Status status = DB::Open (options, myapp::kvs_path, &kvs);

    if (!status.ok()) {
        std::cerr << "Unable to open/create test database '" << myapp::kvs_path << "'" << std::endl;
        return -1;
    }
    
    uint64_t num_workers { 1 };
    uint64_t total_ops { 10000 };

    // execute workload
    // auto workload_duration = myapp::run_workload (kvs, myapp::Workload::writeseq, total_ops, num_workers);

    // workload report
    // std::cout << "Duration: " << workload_duration.count () << "s" << std::endl;
    // std::cout << "Throughput: " << (total_ops * num_workers) / workload_duration.count () << "ops/s" << std::endl;

    myapp::simple_put (kvs, 1);
    myapp::simple_put (kvs, 2);
    myapp::simple_put (kvs, 3);
    myapp::simple_put (kvs, 4);
    myapp::simple_put (kvs, 10);

    myapp::simple_get (kvs, 10);
    myapp::simple_delete (kvs, 10);
    myapp::simple_get (kvs, 10);
    
    myapp::simple_scan (kvs, 3, 5);
    
    // close the KVS
    delete kvs;

    return 0;
}