#!/bin/bash
#SBATCH --job-name=spark-pi      # create a short name for your job
#SBATCH --nodes=3
#SBATCH --ntasks-per-node=4
#SBATCH --time=00:55:00          # total run time limit (HH:MM:SS)
#SBATCH --account=<ACCOUNT_NAME>
#SBATCH --partition=normal-arm
#SBATCH --output=start_cluster.out  # std out
#SBATCH --error=start_cluster.err   # std err

source /share/env/module_select.sh
module purge
module load "Python/3.12.3-GCCcore-13.3.0"
module load "Java/17.0.6"
module load "OpenMPI/5.0.3-GCC-13.3.0"

PYTHON_ENV=<projects_PATH_TO_ENV/>
source ${PYTHON_ENV}/bin/activate
export PYTHONPATH=${PYTHON_ENV}/bin/python
export PYSPARK_PYTHON=${PYTHON_ENV}/bin/python
export PYSPARK_DRIVER_PYTHON=${PYTHON_ENV}/bin/python
export SPARK_HOME=<_PATH_TO_SPARK_spark-version>-bin-hadoop3
export PATH="${SPARK_HOME}/bin:${PATH}"

scontrol show hostnames | sed -n '2,$p' > $SPARK_HOME/conf/workers

# Start the spark cluster
$SPARK_HOME/sbin/start-all.sh
sleep infinity
