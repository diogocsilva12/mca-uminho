#!/bin/bash
#SBATCH --job-name=spark-pi-client      # create a short name for your job
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=4
#SBATCH --time=00:55:00          # total run time limit (HH:MM:SS)
#SBATCH --account=<ACCOUNT_NAME>
#SBATCH --partition=normal-arm
#SBATCH --output=start_client.out  # std out
#SBATCH --error=start_client.err   # std err

module purge
module load "Java/17.0.6"
module load "Python/3.12.3-GCCcore-13.3.0"

# This is basically the same steps as seen in the first subchapter

# Remember to change this to the actual path
export SPARK_HOME=<_PATH_TO_SPARK_spark-version>-bin-hadoop3

# Add to the global PATH
export PATH="${SPARK_HOME}/bin:${PATH}"


# Get the master node, which will be the first node from the command `scontrol show hostnames`
export SPARK_JOB_NAME=<NAME_OF_THE_SPARK_CLUSTE_JOB>
export master_node=$(scontrol show hostnames "$(squeue -u $USER -n ${SPARK_JOB_NAME} -h -o "%N")" | head -1)

# Submit job to the Spark Cluster using spark-submit
# In this script we submit a provided example in the spark directory
$SPARK_HOME/bin/spark-submit \
    --master spark://${master_node}:7077 \
    $SPARK_HOME/examples/src/main/python/pi.py  10
